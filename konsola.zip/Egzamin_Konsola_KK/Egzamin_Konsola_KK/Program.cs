﻿using System;
using System.Linq;

public class Program
{
    public static void Main()
    {
        Console.WriteLine("Aplikacja tworząca elementy w tablicy i wykonująca funkcje na nich");

        const int rozmiar = 25;
        Tablica tab = new Tablica(rozmiar);

        tab.Wyswietl();

        Console.WriteLine("Podaj liczbę do wyszukania w tablicy:");
        if (int.TryParse(Console.ReadLine(), out int szukana))
        {
            int indeks = tab.Szukaj(szukana);
            if (indeks != -1)
            {
                Console.WriteLine("Znaleziono na indeksie: " + indeks);
            }
        }

        int liczbaNieparzystych = tab.NieParzyste();
        Console.WriteLine("Razem nieparzystych: " + liczbaNieparzystych);

        Console.WriteLine("Średnia wszystkich elementów: " + tab.Srednia());
    }
}

public class Tablica
{
    private int[] tablica = [];
    private int Len = 0;

    public Tablica(int len)
    {
        Len = len;
        Random random = new Random();
        for (int i = 0; i < Len; i++)
        {
            tablica = tablica.Append(random.Next(1, 1001)).ToArray();
        }
    }

    //**********************************************
    //nazwa metody: Wyswietl
    //opis metody: wyświetla wszystkie elementy z tablicy
    //parametry: brak
    //zwracany typ i opis: brak
    //autor: 123456789010
    //***********************************************
    public void Wyswietl()
    {
        for (int i = 0; i < Len; i++)
        {
            Console.WriteLine(i + ": " + tablica[i]);
        }
    }

    //**********************************************
    //nazwa metody: Szukaj
    //opis metody: wyszukuje podaną wartość w tablicy i przerywa pętlę po pierwszym trafieniu
    //parametry: szukana - liczba całkowita szukana w tablicy
    //zwracany typ i opis: int - indeks pierwszego wystąpienia lub -1, gdy nie znaleziono
    //autor: 123456789010
    //***********************************************
    public int Szukaj(int szukana)
    {
        for (int i = 0; i < Len; i++)
        {
            if (tablica[i] == szukana)
            {
                return i;
            }
        }
        return -1;
    }

    //**********************************************
    //nazwa metody: NieParzyste
    //opis metody: wyświetla wszystkie nieparzyste elementy z tablicy i zwraca ich liczbę
    //parametry: brak
    //zwracany typ i opis: int - liczba elementów nieparzystych w tablicy
    //autor: 123456789010
    //***********************************************
    public int NieParzyste()
    {
        int nieparzyste = 0;
        Console.WriteLine("Liczby nieparzyste:");
        for (int i = 0; i < Len; i++)
        {
            if (tablica[i] % 2 != 0)
            {
                nieparzyste++;
                Console.WriteLine(tablica[i]);
            }
        }
        return nieparzyste;
    }

    //**********************************************
    //nazwa metody: Srednia
    //opis metody: oblicza średnią arytmetyczną wszystkich elementów z tablicy
    //parametry: brak
    //zwracany typ i opis: double - średnia wszystkich elementów
    //autor: 123456789010
    //***********************************************
    public double Srednia()
    {
        int sum = 0;
        for (int i = 0; i < Len; i++)
        {
            sum += tablica[i];
        }
        return (double)sum / Len;
    }
}