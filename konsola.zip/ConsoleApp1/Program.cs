﻿using System;
static void Main()
{
    Console.WriteLine("Aplikacja tworząca elementy w tablicy i wykonująca funkcje na nich");
    Console.WriteLine("Podaj długość tablicy (tylko liczby dodatnie): ");
    int len = Convert.ToInt32(Console.ReadLine());
    Tablica tab = new(len);
    tab.Wyswietl();
    tab.NieParzyste();
    tab.Srednia();
}
Main();
public class Tablica
{
    public int[] tablica = [];
    public int Len = 0;
    public Tablica(int len)
    {
        Len = len;
        Random random = new Random();
        for (int i = 0; i < Len; i++)
        {
            tablica = tablica.Append(random.Next(1,1000)).ToArray();
        }
    }
    //**********************************************
    //nazwa metody: Wyswietl
    //opis metody: wyświetla wszystkie elementy z tablicy
    //parametry: brak
    //zwracany typ i opis: brak
    //autor: 123456789010
    //***********************************************
    public void Wyswietl()
    {
        for (int i = 0; i < Len; i++)
        {
            Console.WriteLine(i + ": " + tablica[i]);
        }

    }
    //**********************************************
    //nazwa metody: NieParzyste
    //opis metody: wyświetla wszystkie nieparzyste elementy z tablicy
    //parametry: brak
    //zwracany typ i opis: brak
    //autor: 123456789010
    //***********************************************
    public void NieParzyste()
    {
        int nieparzyste = 0;
        Console.WriteLine("Liczby nieparzyste: ");
        for (int i = 0; i < Len; i++)
        {
            if (tablica[i] % 2 != 0)
            {
                nieparzyste++;
                Console.WriteLine(tablica[i]);
            }
        }
        Console.WriteLine("Razem nieparzystych: " + nieparzyste);
    }
    //**********************************************
    //nazwa metody: Wyswietl
    //opis metody: wyświetla średnią wszystkich elementów z tablicy
    //parametry: brak
    //zwracany typ i opis: brak
    //autor: 123456789010
    //***********************************************
    public void Srednia()
    {
        int sum = 0;
        for (int i = 0; i < Len; i++)
        {
            sum = sum + tablica[i];
        }
        int srednia = sum / Len;
        Console.WriteLine("Średnia wszystkich elementów: "+srednia);
    }
}


